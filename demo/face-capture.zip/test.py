import dlib

def detect_face(image_path):
    # Load the image
    image = dlib.load_rgb_image(image_path)

    # Initialize face detector
    face_detector = dlib.get_frontal_face_detector()

    # Detect faces in the image
    faces = face_detector(image)

    # Return True if faces were detected, False otherwise
    if len(faces) > 0:
        return True
    else:
        return False

# Example usage:
image_path = "name.png"
if detect_face(image_path):
    print("Face detected!")
else:
    print("No face detected.")